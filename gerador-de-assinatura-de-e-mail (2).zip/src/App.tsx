
import React, { useState, useRef, useCallback } from 'react';
import { SignatureData } from './types.ts';
import SignaturePreview from './components/SignaturePreview.tsx';
import ImageUploader from './components/ImageUploader.tsx';

type SignatureType = 'vpa_urbanismo' | 'grupo_vpa';

const App: React.FC = () => {
  const [signatureData, setSignatureData] = useState<SignatureData>({
    name: 'Carolina Lattanzio',
    title: 'Gente e Gestão',
    phone: '(31) 2118-4361',
    mobile: '',
    photo: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png',
    photoUrl: '',
  });
  const [copied, setCopied] = useState(false);
  const [signatureType, setSignatureType] = useState<SignatureType>('grupo_vpa');

  const signatureRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSignatureData(prev => ({ ...prev, [name]: value }));
  };

  const handlePhotoUpload = (photo: string) => {
    setSignatureData(prev => ({ ...prev, photo, photoUrl: '' }));
  };

  const handleUrlChange = (photoUrl: string) => {
    setSignatureData(prev => ({ ...prev, photoUrl }));
  };

  const copyHtmlToClipboard = useCallback(() => {
    if (signatureRef.current) {
      const htmlContent = signatureRef.current.innerHTML;
      const listener = (e: ClipboardEvent) => {
        e.clipboardData?.setData('text/html', htmlContent);
        e.clipboardData?.setData('text/plain', htmlContent);
        e.preventDefault();
      };
      document.addEventListener('copy', listener);
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy HTML: ', err);
      } finally {
        document.removeEventListener('copy', listener);
      }
    }
  }, []);

  const handlePreviewHtml = useCallback(() => {
    if (signatureRef.current) {
      const htmlContent = signatureRef.current.innerHTML;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write('<html><head><title>Prévia 2.0</title></head><body style="padding: 20px;">' + htmlContent + '</body></html>');
        newWindow.document.close();
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#F3F4F6] py-12 px-4 font-sans">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8 md:p-12 border-b border-gray-100 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <h1 className="text-3xl font-extrabold text-[#203864]">Gerador de Assinaturas 2.0</h1>
            <p className="text-gray-500 mt-2 text-sm italic">Atualizado com otimização de imagem para Outlook</p>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => setSignatureType('vpa_urbanismo')}
              className={`px-4 py-2 rounded-lg border-2 transition-all ${signatureType === 'vpa_urbanismo' ? 'border-[#19a649] bg-green-50' : 'border-gray-200 bg-white'}`}
            >
              <img src="https://www.vpaurbanismo.com.br/assinaturadeemail/vpa_assinatura.png" alt="Urbanismo" className="h-8 object-contain" />
            </button>
            <button 
              onClick={() => setSignatureType('grupo_vpa')}
              className={`px-4 py-2 rounded-lg border-2 transition-all ${signatureType === 'grupo_vpa' ? 'border-[#203864] bg-blue-50' : 'border-gray-200 bg-white'}`}
            >
              <img src="https://vpaurbanismo.com.br/assinaturadeemail/grupovpa_assinatura.png" alt="Grupo VPA" className="h-8 object-contain" />
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2">
          <div className="p-8 space-y-6 border-r border-gray-100">
            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#203864] text-white flex items-center justify-center text-xs">1</span>
              Informações Pessoais
            </h2>
            
            <ImageUploader 
              onPhotoUpload={handlePhotoUpload} 
              onUrlChange={handleUrlChange}
              currentPhoto={signatureData.photo} 
              currentUrl={signatureData.photoUrl}
            />

            <div className="grid gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 uppercase">Nome</label>
                <input type="text" name="name" value={signatureData.name} onChange={handleInputChange} className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#203864] focus:outline-none" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 uppercase">Cargo</label>
                <input type="text" name="title" value={signatureData.title} onChange={handleInputChange} className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#203864] focus:outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 uppercase">Telefone</label>
                  <input type="text" name="phone" value={signatureData.phone} onChange={handleInputChange} className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#203864] focus:outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 uppercase">Celular</label>
                  <input type="text" name="mobile" value={signatureData.mobile} onChange={handleInputChange} className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#203864] focus:outline-none" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 bg-gray-50 flex flex-col">
             <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2 mb-6">
              <span className="w-6 h-6 rounded-full bg-[#203864] text-white flex items-center justify-center text-xs">2</span>
              Visualização Final
            </h2>
            
            <div className="bg-white p-6 rounded-xl shadow-inner border border-gray-200 min-h-[160px] flex items-center justify-center overflow-x-auto">
               <SignaturePreview data={signatureData} signatureType={signatureType} />
            </div>

            <div className="mt-auto pt-8 space-y-4">
              <button
                onClick={copyHtmlToClipboard}
                className={`w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg hover:shadow-xl transform active:scale-95 ${copied ? 'bg-green-500' : 'bg-[#203864] hover:bg-[#1a2d52]'}`}
              >
                {copied ? '✓ HTML COPIADO!' : 'COPIAR PARA O OUTLOOK'}
              </button>
              <button
                onClick={handlePreviewHtml}
                className="w-full py-2 text-sm text-gray-500 hover:text-gray-800 font-medium transition-colors underline"
              >
                Abrir em nova aba para teste
              </button>
            </div>
          </div>
        </div>
      </div>

      <div ref={signatureRef} className="hidden">
        <SignaturePreview data={signatureData} isHtmlGeneration={true} signatureType={signatureType} />
      </div>
    </div>
  );
};

export default App;
