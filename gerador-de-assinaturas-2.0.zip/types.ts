export interface SignatureData {
  name: string;
  title: string;
  phone: string;
  photo: string;
  mobile?: string;
}