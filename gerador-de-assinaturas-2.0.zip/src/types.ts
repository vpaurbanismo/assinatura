
export interface SignatureData {
  name: string;
  title: string;
  phone: string;
  photo: string;
  photoUrl?: string;
  mobile?: string;
}
