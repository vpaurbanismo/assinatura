
import React, { useState, FormEvent } from 'react';

interface PasswordProtectionProps {
  children: React.ReactNode;
}

const CORRECT_PASSWORD = 'vpa2024';

const PasswordProtection: React.FC<PasswordProtectionProps> = ({ children }) => {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState('');

  const handlePasswordSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (password === CORRECT_PASSWORD) {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Senha incorreta. Tente novamente.');
    }
  };

  if (isAuthenticated) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-[#F3F4F6] flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-[2rem] shadow-2xl p-8 md:p-12 border border-gray-100 relative overflow-hidden">
            {/* Faixa decorativa de versão no topo */}
            <div className="absolute top-0 right-0 bg-[#19a649] text-white text-[10px] font-black px-8 py-1 rotate-45 translate-x-6 translate-y-2 shadow-sm">
              NOVA VERSÃO
            </div>

            <div className="text-center mb-10">
                <img 
                  src="https://www.vpaurbanismo.com.br/assinaturadeemail/vpa_assinatura.png" 
                  alt="VPA Urbanismo Logo" 
                  className="w-[160px] h-auto object-contain mx-auto mb-8" 
                />
                
                <h1 className="text-4xl font-black text-[#203864] leading-none tracking-tighter">
                  Gerador de<br/>Assinaturas
                </h1>
                
                <div className="mt-4 flex flex-col items-center justify-center">
                  <span className="text-5xl font-black text-[#19a649] drop-shadow-sm">2.0</span>
                  <div className="h-1 w-20 bg-[#19a649] rounded-full mt-1"></div>
                  <p className="text-[#203864] text-[10px] font-bold uppercase tracking-[0.2em] mt-2 opacity-60">Sistemas VPA</p>
                </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <label htmlFor="password" className="block text-center text-[10px] font-black text-gray-400 uppercase tracking-widest">Senha de Acesso</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="block w-full px-4 py-4 bg-white border-2 border-gray-200 rounded-xl shadow-inner focus:outline-none focus:ring-2 focus:ring-[#19a649] focus:border-transparent text-center font-bold text-[#203864] text-lg transition-all"
                            placeholder="••••••••"
                        />
                    </div>
                    
                    {error && (
                      <p className="text-red-600 text-[11px] font-black text-center animate-pulse">
                        {error}
                      </p>
                    )}
                    
                    <button
                        type="submit"
                        className="w-full text-white font-black py-4 px-4 rounded-xl transition-all duration-300 bg-[#203864] hover:bg-[#1a2d52] shadow-lg hover:shadow-xl active:scale-[0.98] uppercase tracking-widest text-sm flex items-center justify-center gap-2"
                    >
                        ACESSAR FERRAMENTA
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                    </button>
                </form>
            </div>
            
            <p className="text-center text-gray-400 text-[9px] mt-10 font-bold uppercase tracking-widest">
              Desenvolvido pelo Departamento de Marketing
            </p>
        </div>
      </div>
    </div>
  );
};

export default PasswordProtection;
